import {Page} from "./Page.jsx";

export function App() {
  return <Page />;
}
